package Assignment1;

public interface Colorable {
    void howToColor();
}
