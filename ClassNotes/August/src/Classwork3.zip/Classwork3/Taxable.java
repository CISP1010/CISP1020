package Classwork3;

public interface Taxable {

    double getTaxable();
}