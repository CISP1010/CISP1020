package Classwork4;

public class NanException extends Exception {
    public NanException() {
    }
public NanException(String message) {
        super(message);
    }
}
