package Notes09_05_23.polymorphism;

public class GraduateStudent {
}
