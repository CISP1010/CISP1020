package Notes09_05_23.polymorphism;
public class Person {
    public String toString()
    {
        return "Person";
    }
}
