package Notes08_15_23;

public class PrintF_Scratch {
    public static void main(String[] args) {
        String item = "Laptop";
        double price = 299.856;
        int warranty = 2;
        System.out.printf("Item : %10s\nPrice : %10s\nWarranty : %10s\n", item, price, warranty);
    }
}
