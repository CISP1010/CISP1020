package Notes09_05_23;


    // IM SO FUCKING TIREDDDDD

    //look up dynamic binding and polymorphism from last class

   // Public class Circle{ == Public class Circle extend Object{

public class Notes {

}

